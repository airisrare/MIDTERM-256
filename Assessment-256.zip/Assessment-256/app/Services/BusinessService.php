<?php
namespace App\Services;

use App\Models\UserModel;

class BusinessService
{
    //compare to make sure the user has the same password
    public function compare(UserModel $userinfo)
    {
        //creating the $password set to the password we want
        $password = "CST-256";
        //creating an instance of the user model
        $usermodel = new UserModel();
        
        //if our password is == to the user model password we return true
        if($password == $usermodel->getPassword())
            return true;
        
        else
        {
            return false;
        }
    }
}

