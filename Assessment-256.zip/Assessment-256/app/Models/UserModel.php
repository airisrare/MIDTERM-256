<?php
namespace App\Models;

class UserModel
{
    //variables for our user
    private $firstname;
    private $lastname;
    private $password;
    private $color;

    //constructor for the userModel
public function _construct($firstname, $lastname,$password, $color)
{
    //this will be our key
    $this->firstname = $firstname;
    $this->lastname = $lastname;
    $this->password = $password;
    $this->color = $color;
    
}

//Getters and setters
    public function getFirstname()
    {
        return $this->firstname;
    }


    public function getLastname()
    {
        return $this->lastname;
    }

    public function getPassword()
    {
        return $this->password;
    }


    public function getColor()
    {
        return $this->color;
    }

/**
     * @param Ambigous <string, unknown> $firstname
     */
    public function setFirstname($firstname)
    {
        $this->firstname = $firstname;
    }

/**
     * @param Ambigous <string, unknown> $lastname
     */
    public function setLastname($lastname)
    {
        $this->lastname = $lastname;
    }

/**
     * @param Ambigous <string, unknown> $password
     */
    public function setPassword($password)
    {
        $this->password = $password;
    }

/**
     * @param string $color
     */
    public function setColor($color)
    {
        $this->color = $color;
    }

}