<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserModel;
use App\Services\BusinessService;

class LoginController extends Controller
{
   public function index(Request $request)
   {
       //putting our data into the usermodel
       $data = new UserModel($request->get('firstname'),$request->get('lastName'),
           $request->get('password'),$request->get('color'));
       
       //instatntiate the business layer
       $businessService = new BusinessService();
       
       //creating a valid which is using the businsess service and comparing the data we give it
       //inside of our business service, we are comparing password
       //in my program password is where we are checking for cst 256
       $Valid = $businessService->compare($data);
       
       if($Valid)
       {
          
           
       return view("Assessment")->with($data);
       echo "Success";
       }
       else{
           return view("Assessment");
           echo "Failed";
       }
      
       

       
       //$data = ['firstName' => $firstname, 'lastName' => $lastname, 'password' => $pass, 'color' => $color];
       
   }
}